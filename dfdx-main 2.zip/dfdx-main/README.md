# dfdx
A [Mr Deep Fakes](https://mrdeepfakes.com) video downloader userscript

# INSTRUCTIONS.
Go onto [MrDeepFakes](https://mrdeepfakes.com)'s front page, right click on a video; example I've used is Foundryguy's [Not Ana de Armas pov PREVIEW](https://mrdeepfakes.com/video/78716/not-ana-de-armas-pov-preview). Click "Open in New Tab" or whatever opens a link you've right clicked in a new tab. This will take a couple seconds to grab the video link and once it does, it'll auto-close the page. After this it most likely will ask you where to save it, that's up to you. There's a possibility it might complain about download permissions; to fix this, go down to "Downloads BETA" and change "Download Mode" from it's default to "Browser API". After this, it should work flawlessly. You can open multiple tabs and it'll continue without a hitch, only problem will be MDF and server speeds, your connection, and if the video is even accessible to this method. Most are though, so don't worry.

After everything is said and done, in the famous words of Scarface; The World is Yours.

Linux version is dfdx.linux.user.js and Windows is dfdx.windows.user.js (All this changes is how file paths are.)

# CREDITS.
MrDeepFakes for the site, myself for being baller (Joke of course) and JDipi for his [Soap2Day Downloader](https://github.com/JDipi/soap2day-downloader). (R.I.P S2D Btw.)
<br>Isn't it crazy what chain of custody for open source can cause?
